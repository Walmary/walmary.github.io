/*import WORDS from "../wordle.json"
console.log(WORDS)
*/



/*we take the elemnt where is going the words  */
const charcontainer = document.querySelector('.char-container')

console.log(charcontainer)

/*we create the panel of words and letters
 with an array words a letters */
const guessWords = [
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', '']
]


/*we need to create a div element and set up the id attribute 
  in order to identify each element of the array guessWords  */

guessWords.forEach((guessWord, guessWordIndex) => {
    const wordElement = document.createElement('div')
    wordElement.setAttribute("id", "guessWord-" + guessWordIndex)
    guessWord.forEach((guessChar, guessCharIndex) => {
        const charElement = document.createElement('div')
        charElement.setAttribute("id", "guessWord-" + guessWordIndex + "-char-" + guessCharIndex)
        wordElement.append(charElement)
    })
    charcontainer.append(wordElement)
});








/*I need to create the keyboard
I will use buttons to know which
key was pressed and replicate it 
in the boxes 05/03/2022*/

/*we choose the keyboard 
container to create the keyboard element*/
const keyboard = document.querySelector('.keyboard-container')

const pressClick = () => {
    console.log('clicked')
}

/*create the button html element for each letter of the keyboard */
const buttonElement = document.createElement('button')
buttonElement.textContent = 'Q'
buttonElement.setAttribute('id', 'Q')
buttonElement.addEventListener('click', pressClick)
keyboard.append(buttonElement)

const buttonElement1 = document.createElement('button')
buttonElement1.textContent = 'W'
buttonElement1.setAttribute('id', 'W')
buttonElement1.addEventListener('click', pressClick)
keyboard.append(buttonElement1)

const buttonElement2 = document.createElement('button')
buttonElement2.textContent = 'E'
buttonElement2.setAttribute('id', 'E')
buttonElement2.addEventListener('click', pressClick)
keyboard.append(buttonElement2)