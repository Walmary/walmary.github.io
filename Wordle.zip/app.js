/*I need to create the keyboard
I will use buttons to know which
key was pressed and replicate it 
in the boxes 05/03/2022*/

/*we choose the keyboard 
container to create the keyboard element*/
const keyboard = document.querySelector('.keyboard-container')

const handleClick = () => {
    console.log('clicked')
}

/*create the button html element for each letter of the keyboard */
const buttonElement = document.createElement('button')
buttonElement.textContent = 'Q'
buttonElement.setAttribute('id', 'Q')
buttonElement.addEventListener('click', handleClick)
keyboard.append(buttonElement)

const buttonElement1 = document.createElement('button')
buttonElement1.textContent = 'W'
keyboard.append(buttonElement1)