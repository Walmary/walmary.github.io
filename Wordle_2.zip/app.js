/*import WORDS from "../wordle.json"
console.log(WORDS)
*/



/*we take the elemnt where is going the words  */
const charcontainer = document.querySelector('.char-container')
console.log(charcontainer)

/*we create the panel of words and letters
 with an array words a letters */
const guessWords = [
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', '']
]

let currentWord = 0
let currentChar = 0

/*we need to create a div element and set up the id attribute 
  in order to identify each element of the array guessWords  */

guessWords.forEach((guessWord, guessWordIndex) => {
    const wordElement = document.createElement('div')
    wordElement.setAttribute("id", "guessWord-" + guessWordIndex)
    guessWord.forEach((guessChar, guessCharIndex) => {
        const charElement = document.createElement('div')
        charElement.setAttribute("id", "guessWord-" + guessWordIndex + "-char-" + guessCharIndex)
        charElement.classList.add('char')
        wordElement.append(charElement)
    })
    charcontainer.append(wordElement)
});



/*I need to create the keyboard
I will use buttons to know which
key was pressed and replicate it 
in the boxes 05/03/2022*/

/*we choose the keyboard 
container to create the keyboard element*/
const keyboard = document.querySelector('.keyboard-container')


/*we create an array for the alphabet*/
const chars = [
    'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 'A', 'S', 'D', 'F', 'G', 'H',
    'J', 'K', 'L', 'ENTER', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', "<<"
]

/*create the button html element for each letter of the keyboard */
chars.forEach(char => {
        const buttonElement = document.createElement('button')
        buttonElement.textContent = char
        buttonElement.setAttribute('id', char)
        buttonElement.addEventListener('click', () => pressClick(char))
        keyboard.append(buttonElement)

    })
    /*create the button html element for each letter of the keyboard */
    /*const buttonElement = document.createElement('button')
    buttonElement.textContent = 'Q'
    buttonElement.setAttribute('id', 'Q')
    buttonElement.addEventListener('click', () => pressClick('Q'))
    keyboard.append(buttonElement)

    const buttonElement1 = document.createElement('button')
    buttonElement1.textContent = 'W'
    buttonElement1.setAttribute('id', 'W')
    buttonElement1.addEventListener('click', () => pressClick(buttonElement1.textContent))
    keyboard.append(buttonElement1)

    const buttonElement2 = document.createElement('button')
    buttonElement2.textContent = 'E'
    buttonElement2.setAttribute('id', 'E')
    buttonElement2.addEventListener('click', () => pressClick(buttonElement2.textContent))
    keyboard.append(buttonElement2)*/

/**this function recognizes the pressed key */
const pressClick = (charValue) => {
        console.log('clicked', charValue)
        if (charValue === '<<') {
            eraseChar()
            return
        }
        if (charValue === 'ENTER') {
            console.log('check word')
            return
        }
        addChar(charValue)
    }
    /**this function places the pressed letter in the grid */
const addChar = (char) => {
    if (currentChar < 5 && currentWord < 6) {
        const charElement = document.getElementById('guessWord-' + currentWord + '-char-' + currentChar)
        charElement.textContent = char
        guessWords[currentWord][currentChar] = char
        charElement.setAttribute("data", char)
        currentChar++;
        console.log('guessWords', guessWords)
    }

}

/**function erase char  */

const eraseChar = () => {
    if (currentChar > 0) {
        console.log('esoy en erase ')
        currentChar--
        const charElement = document.getElementById('guessWord-' + currentWord + '-char-' + currentChar)
        charElement.textContent = ''
        guessWords[currentWord][currentChar]
        charElement.setAttribute('data', '')

    }
}


/*   switch (char) {
    case '<<':
        console.log('dentro del  ' + char);
        charElement.textContent = '';
        currentChar--;
        break;
    case 'ENTER':
        console.log('dentro del  ' + char);
        charElement.textContent = '';
        currentChar = 0;
        currentWord++;
    default:
        charElement.textContent = char;
        currentChar++;


}*/

/*    if (currentChar <= 5) {
        charElement.textContent = char
        currentChar++

    }
*/